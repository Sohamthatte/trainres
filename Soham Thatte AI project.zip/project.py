#!/usr/bin/env python
# coding: utf-8

# In[16]:


import nltk

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[28]:


dataset=pd.read_csv("spam.tsv",sep='\t',header=None)
dataset.columns=['label','body_text']
dataset.head()


# In[63]:


dataset.isnull()


# In[64]:


dataset.isnull().sum()


# In[18]:


print("Input data has {} rows and {} columns".format(len(dataset),len(dataset.columns)))


# In[65]:


len(dataset)


# In[66]:


dataset['label'].value_counts()


# In[68]:


#balancing data
ham=dataset[dataset['label']=='ham']
ham.head()


# In[69]:


spam=dataset[dataset['label']=='spam']
spam.head()


# In[70]:


data=ham.append(spam, ignore_index=True)
data.tail()


# In[71]:


ham.shape, spam.shape


# In[72]:


data=ham.append(spam, ignore_index=True)
data.tail()


# # explratory data analysis

# In[83]:


plt.hist(data[data['label']=='ham']['body_len'], bins=100, alpha=0.7)
plt.hist(data[data['label']=='spam']['body_len'], bins=100, alpha=0.7)
plt.show()


# In[84]:


plt.hist(data[data['label']=='ham']['punct%'], bins=100, alpha=0.7)
plt.hist(data[data['label']=='spam']['punct%'], bins=100, alpha=0.7)
plt.show()


# In[86]:


from sklearn.model_selection  import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score,classification_report, confusion_matrix
from sklearn.pipeline import Pipeline


# In[87]:


from sklearn.feature_extraction.text import TfidfVectorizer


# In[88]:


data.head()


# In[109]:


X_train,X_test,y_train,y_test=train_test_split(data['body_text'],data['label'],test_size=0.3,random_state=0,shuffle=True,stratify=data['label'])


# In[99]:


vectorizer = TfidfVectorizer()


# In[101]:


X_train=vectorizer.fit_transform(X_train)


# In[103]:


X_train.shape


# In[104]:


X_train


# # pipeline

# In[106]:


clf = Pipeline([('tfidf',TfidfVectorizer()),('clf',RandomForestClassifier(n_estimators=100,n_jobs=-1))])


# In[111]:


clf.fit(X_train, y_train)


# In[112]:


y_pred=clf.predict(X_test)


# In[113]:


confusion_matrix(y_test, y_pred)


# In[114]:


print(classification_report(y_test,y_pred))


# In[115]:


accuracy_score(y_test, y_pred)


# In[124]:


clf.predict(["India is my country"])


# # SVC

# In[129]:


clf = Pipeline([('tfidf',TfidfVectorizer()),('clf',SVC(C=100,gamma='auto'))])    


# In[130]:


clf.fit(X_train, y_train)


# In[131]:


confusion_matrix(y_test, y_pred)


# In[132]:


print(classification_report(y_test,y_pred))


# In[133]:


accuracy_score(y_test, y_pred)


# In[134]:


clf.predict(["India is my country"])


# In[135]:





# In[ ]:





# In[19]:


print("Number of null in label: {}".format(dataset['label'].isnull().sum()))
print("Number of null in body_text: {}".format(dataset['body_text'].isnull().sum()))


# In[20]:


import string
string.punctuation


# # Here we are removing punctuation

# In[21]:


def remove_punct(text):
    text_nopunct="".join([char for char in text if char not in string.punctuation])
    return text_nopunct

dataset['body_text_clean']=dataset['body_text'].apply(lambda x:remove_punct(x))
dataset.head()


# In[22]:


import re
def tokenize(text):
    tokens=re.split('\W',text)
    return tokens
dataset['body_text_tokenized']=dataset['body_text_clean'].apply(lambda x:tokenize(x.lower()))
dataset.head()


# In[23]:


nltk.download('stopwords') #downloadingstopwordsset
stopwords=nltk.corpus.stopwords.words('english')

def remove_sw(tokenized_list):
    text=[word for word in tokenized_list if word not in stopwords]
    return text
dataset['body_text_nostop']=dataset['body_text_tokenized'].apply(lambda x:remove_sw(x))
dataset.head()


# # Performing Stemming

# In[24]:


#from nltk.stem.porter import *
ps=nltk.PorterStemmer()
def stemming(tokenized_text):
    text=[ps.stem(word) for word in tokenized_text]
    return text
dataset['body_text_stemmed']=dataset['body_text_nostop'].apply(lambda x:stemming(x))
dataset.head()


# # Lemmatizing

# In[25]:


wn=nltk.WordNetLemmatizer()

def lemmatizing(tokenized_text):
    text=[ps.stem(word) for word in tokenized_text]
    return text
dataset['body_text_lemmatized']=dataset['body_text_nostop'].apply(lambda x:lemmatizing(x))
dataset.head()


# In[26]:


get_ipython().system('pip install scikit-learn')


# In[27]:


import sklearn as sklearn


# In[33]:


from sklearn.feature_extraction.text import CountVectorizer

def clean_text(text):
    text="".join([word.lower() for word in text if word not in string.punctuation])
    tokens=re.split('\W',text)
    text=[ps.stem(word) for word in tokens if word not in stopwords]
    return text

count_vect= CountVectorizer(analyzer=clean_text)
X_count=count_vect.fit_transform(dataset['body_text'])
print(X_count.shape)
print(count_vect.get_feature_names())


# In[34]:


X_count


# In[39]:


x_counts_df=pd.DataFrame(X_count.toarray())
x_counts_df


# In[42]:


x_count_df.columns=count_vect.get_feature_names()
x_counts_df


# # TF-IDF

# In[46]:


from sklearn.feature_extraction.text import TfidfVectorizer
tfidf_vect=TfidfVectorizer(analyzer=clean_text)
X_tfidf=tfidf_vect.fit_transform(dataset['body_text'])
print(X_tfidf.shape)
print(tfidf_vect.get_feature_names())


# In[47]:


x_tfidf_df=pd.DataFrame(X_tfidf.toarray())
x_tfidf_df.columns=tfidf_vect.get_feature_names()
x_tfidf_df


# # Feature Engineering

# In[48]:


dataset=pd.read_csv("spam.tsv",sep='\t',header=None)
dataset.columns=['label','body_text']
dataset.head()


# In[49]:


dataset["body_len"]=dataset["body_text"].apply(lambda x:len(x)-x.count(" "))

dataset.head()


# In[50]:


def count_punct(text):
    count=sum([1 for char in text if char in string.punctuation])
    return round(count/(len(text)-text.count(" ")),3)*100

dataset["punct%"]=dataset["body_text"].apply(lambda x:count_punct(x))

dataset.head()


# In[51]:


import matplotlib.pyplot as plt
import numpy as np

bins=np.linspace(0,200,40)

plt.hist(dataset['body_len'],bins)
plt.title("Body Length Distribution")
plt.show()


# In[52]:


bins=np.linspace(0,50,40)

plt.hist(dataset['punct%'],bins)
plt.title('Punctuation % Distribution')
plt.show()


# In[54]:


dataset=pd.read_csv("spam.tsv",sep='\t',header=None)
dataset.columns=['label','body_text']
dataset.head()


# In[55]:


def count_punct(text):
    count=sum([1 for char in text if char in string.punctuation])
    return round(count/(len(text)-text.count(" ")),3)*100

dataset["body_len"]=dataset["body_text"].apply(lambda x:len(x)-x.count(" "))
dataset["punct%"]=dataset["body_text"].apply(lambda x:count_punct(x))

dataset.head()


# In[56]:


def clean_text(text):
    text="".join([word.lower() for word in text if word not in string.punctuation])
    tokens=re.split('\W',text)
    text=[ps.stem(word) for word in tokens if word not in stopwords]
    return text

tfidf_vect=TfidfVectorizer(analyzer=clean_text)
X_tfidf=tfidf_vect.fit_transform(dataset['body_text'])


# In[57]:


X_features=pd.concat([dataset['body_len'],dataset['punct%'],pd.DataFrame(X_tfidf.toarray())],axis=1)
X_features.head()


# In[58]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold, cross_val_score

rf=RandomForestClassifier(n_jobs=1)
k_fold=KFold(n_splits=5)

cross_val_score(rf, X_features, dataset['label'],cv=k_fold, scoring='accuracy',n_jobs=1)


# In[59]:


from sklearn.metrics import precision_recall_fscore_support as score
from sklearn.model_selection import train_test_split


# In[60]:


X_train, X_test, y_train, y_test=train_test_split(X_features, dataset['label'],test_size=0.3,random_state=0)

rf=RandomForestClassifier(n_estimators=50, max_depth=20, n_jobs=-1)
rf_model=rf.fit(X_train, y_train)


# In[61]:


sorted(zip(rf_model.feature_importances_, X_train.columns),reverse=True)[0:10]


# In[ ]:




